```python
import pandas as pd
import random
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

import os
import pathlib
from pathlib import Path
from typing import Tuple, Dict, List

import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torch.utils.data import RandomSampler
                                                                                                                                
import torchvision
from torchvision import transforms
from torchvision import datasets
from torchinfo import summary

from tqdm import tqdm
from timeit import default_timer as timer 
```

### 设置好device，以充分发挥GPU的计算优势，同时要兼容没有GPU的设备


```python
# 数据和模型都要加载到正确的设备上，否则会因不兼容而报错
device = "cuda" if torch.cuda.is_available() else "cpu"
device
```




    'cpu'




```python
# 设置数据文件夹
DATA_PATH = Path("data/")
IMAGE_PATH = DATA_PATH / "wordlib"    #
IMAGE_PATH_LIST = list(IMAGE_PATH.glob("*.gif"))  

# 如果文件夹不存在，则创建一个... 
if IMAGE_PATH.is_dir():
    print(f"{IMAGE_PATH} 文件夹存在，可以使用...")
else:
    print(f"{IMAGE_PATH}文件平不存在，创建中...")
    IMAGE_PATH.mkdir(parents=True, exist_ok=True)
```

    data\wordlib 文件夹存在，可以使用...
    

### 准备数据，查找指定文件夹中包含哪些文字，并设置其classes和labels


```python
# 查找指定文件夹中的classes
def find_classes(directory: str,ext:str='gif') -> Tuple[List[str], Dict[str, int],List[str]]:
    """根据指定文件夹下的图片文件名的第一名字形成类别classes.
    
    书法图片文件命名规范为：字_字体_书法家_文件编号.gif，如：予_行书_鲜于枢_12046.gif.

    Args:
        directory (str): target directory to load distinct words from.

    Returns:
        Tuple[List[str], Dict[str, int]]: (list_of_class_names, dict(class_name: idx...))
    
    Example:
        data\wordlib\予_行书_鲜于枢_12046.gif 分割_前面的字符是书法对应的文字
        >>> (["予", "大",...], {"予": 203, ...})
    """
    # 1. 扫描路径下全部文件，通过文件名首字符为图片所对应的汉字这样的命名规则，得到该路径下的全部汉字。
    image_path_list = list(pathlib.Path(directory).glob(f"*.{ext}"))
    image_classes_set = set()  #因为相同的字有多张图，所以使用set集合去重
    images_classes_list=[]
    images_name_list=[]
    for  path in   image_path_list:
        image_classes_set.add(path.name.split('_')[0])
        images_name_list.append(path.name)
    classes=sorted([word for word in image_classes_set])
    
    # 2. 如果文件不存在或没有按要求命名，则报错
    if not classes:
        raise FileNotFoundError(f"{directory}路径下的文件可能不存在或没有按要求命名（文件命名规则为word_font_writer_number.gif)")
        
    # 3. 创建汉字列表及包含其序号的dict
    class_to_idx=dict()
    for i,word in enumerate(classes):
        class_to_idx[word]=i   

    return classes, class_to_idx, images_name_list
```


```python
## ，是模型训练的基础数据，重要，不要改动
images_classes_list,word_classes_dict,images_name_list=find_classes(IMAGE_PATH,'gif') 
```


```python
print(f'文件夹{IMAGE_PATH}下有{len(images_classes_list)}个不同字的书法图片')
```

    文件夹data\wordlib下有483个不同字的书法图片
    


```python
# 查找指定文件夹中的writer_classes
def find_writer_classes(directory: str,ext:str='gif') -> Tuple[List[str], Dict[str, int],List[str]]:
    """根据指定文件夹下的图片文件名的第一名字形成类别classes.
    
    书法图片文件命名规范为：字_字体_书法家_文件编号.gif，如：予_行书_鲜于枢_12046.gif.

    Args:
        directory (str): target directory to load distinct words from.

    Returns:
        Tuple[List[str], Dict[str, int]]: (list_of_class_names, dict(class_name: idx...))
    
    Example:
        data\wordlib\予_行书_鲜于枢_12046.gif 最后一个分割符_后面的字符是书法对应的作者writer
        >>> (["鲜于枢", "王羲之"], {"王羲之": 266, ...})
    """
    # 1. 扫描路径下全部文件，通过文件名首字符为图片所对应的汉字这样的命名规则，得到该路径下的全部汉字。
    image_path_list = list(pathlib.Path(directory).glob(f"*.{ext}"))
    image_writer_classes_set = set()  #因为相同的字有多张图，所以使用set集合去重
    images_writer_classes_list=[]
    images_writer_name_list=[]
    for  path in   image_path_list:
        image_writer_classes_set.add(path.name.split('_')[2])
        images_writer_name_list.append(path.name)
    writer_classes=sorted([word for word in image_writer_classes_set])
    
    # 2. 如果文件不存在或没有按要求命名，则报错
    if not writer_classes:
        raise FileNotFoundError(f"{directory}路径下的文件可能不存在或没有按要求命名（文件命名规则为word_font_writer_number.gif)")
        
    # 3. 创建汉字列表及包含其序号的dict
    writer_class_to_idx=dict()
    for i,word in enumerate(writer_classes):
        writer_class_to_idx[word]=i   

    return writer_classes, writer_class_to_idx, images_writer_name_list
```


```python
## ，是模型训练的基础数据，重要，不要改动
images_writer_classes_list,word_writer_classes_dict,images_writer_name_list=find_writer_classes(IMAGE_PATH,'gif') 
```


```python
print(f'文件夹{IMAGE_PATH}下有{len(images_writer_classes_list)}个书法家的书法图片')
```

    文件夹data\wordlib下有447个书法家的书法图片
    

### 根据指定文件夹下的图片，生成文字列表，并以Dict保存每个文字的编号


```python
#以DataFrame形式保存字与Label的对应关系
df_word_label_map=pd.DataFrame.from_dict(word_classes_dict,orient='index',columns=['label'])
df_word_label_map.reset_index(inplace=True)
df_word_label_map.columns=['word','label']
df_word_label_map.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>473</th>
      <th>474</th>
      <th>475</th>
      <th>476</th>
      <th>477</th>
      <th>478</th>
      <th>479</th>
      <th>480</th>
      <th>481</th>
      <th>482</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>word</th>
      <td>一</td>
      <td>丁</td>
      <td>七</td>
      <td>万</td>
      <td>丈</td>
      <td>三</td>
      <td>上</td>
      <td>下</td>
      <td>不</td>
      <td>与</td>
      <td>...</td>
      <td>操</td>
      <td>據</td>
      <td>擠</td>
      <td>擢</td>
      <td>擬</td>
      <td>擴</td>
      <td>擾</td>
      <td>攀</td>
      <td>攘</td>
      <td>攜</td>
    </tr>
    <tr>
      <th>label</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>4</td>
      <td>5</td>
      <td>6</td>
      <td>7</td>
      <td>8</td>
      <td>9</td>
      <td>...</td>
      <td>473</td>
      <td>474</td>
      <td>475</td>
      <td>476</td>
      <td>477</td>
      <td>478</td>
      <td>479</td>
      <td>480</td>
      <td>481</td>
      <td>482</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 483 columns</p>
</div>




```python
#以DataFrame形式保存字与Label的对应关系
df_word_writer_label_map=pd.DataFrame.from_dict(word_writer_classes_dict,orient='index',columns=['label'])
df_word_writer_label_map.reset_index(inplace=True)
df_word_writer_label_map.columns=['word','label']
df_word_writer_label_map.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>437</th>
      <th>438</th>
      <th>439</th>
      <th>440</th>
      <th>441</th>
      <th>442</th>
      <th>443</th>
      <th>444</th>
      <th>445</th>
      <th>446</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>word</th>
      <td>丰坊</td>
      <td>乃贤</td>
      <td>乔一琦</td>
      <td>于文傅</td>
      <td>于谦</td>
      <td>井寂严</td>
      <td>仲殊</td>
      <td>任伯年</td>
      <td>任询</td>
      <td>伊秉绶</td>
      <td>...</td>
      <td>鲜于枢</td>
      <td>黄仲则</td>
      <td>黄庭坚</td>
      <td>黄慎</td>
      <td>黄潜</td>
      <td>黄辉</td>
      <td>黄道周</td>
      <td>黎简</td>
      <td>龚晴皋</td>
      <td>龚贤</td>
    </tr>
    <tr>
      <th>label</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>4</td>
      <td>5</td>
      <td>6</td>
      <td>7</td>
      <td>8</td>
      <td>9</td>
      <td>...</td>
      <td>437</td>
      <td>438</td>
      <td>439</td>
      <td>440</td>
      <td>441</td>
      <td>442</td>
      <td>443</td>
      <td>444</td>
      <td>445</td>
      <td>446</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 447 columns</p>
</div>



### 定义函数resolve_word_by_image_name，根据图片文件名找出对应的文字(class)、标签(Label)，并显示该文字图片


```python
def resolve_word_by_image_name(image_path,word_classes_dict,show=True)->(str,str,Image):
    
    '''
    定义函数 resolve_word_by_image_name，根据图片文件名找出对应的文字(class)、标签(Label)，并显示该文字图片
    Args:
        image_path (str): 文字图片路径和文件名.
        word_classes_dict (dict): 文字及标签的字典
        show (Boolean): 是否显示文字图片

    Returns:
        str,str: 文字class,文字label

    Example:
        data\wordlib\予_行书_鲜于枢_12046.gif "_"前面的字符是书法对应的文字
        返回："予",203
    '''
    image_class = Path(str(image_path)).name.split('_')[0]
    image_label =word_classes_dict[image_class]
    print(f'图片{image_path}对应的文字是：{image_class}, 其label为: {image_label}')
    
    
    with Image.open(image_path).convert('RGB') as f: #    丁_草书_王铎_131029.gif data/wordlib/zxqsig.jpg
        if show:
            plt.figure(figsize=(2,2))
            plt.imshow(f)  
            plt.title(f"图片size(H,W)为:({f.height}, {f.width})",fontsize=16,fontproperties='Simhei')
            plt.axis(False)            
    return image_class,image_label,f
```


```python
random_image_path = random.choice(IMAGE_PATH_LIST)
word,label,img=resolve_word_by_image_name(random_image_path,word_classes_dict,show=True)
```

    图片data\wordlib\惊_行书_近人_28296.gif对应的文字是：惊, 其label为: 261
    


    
![png](output_16_1.png)
    


### 创建图片转换Transform，将图片按某种效果进行变换
详见[Pytorch文档: ILLUSTRATION OF TRANSFORMS](https://pytorch.org/vision/stable/auto_examples/plot_transforms.html#sphx-glr-auto-examples-plot-transforms-py)


```python
def resolve_word_writer_by_image_name(image_path,word_writer_classes_dict,show=True)->(str,str,Image):
    
    '''
    定义函数 resolve_word_writer_by_image_name，根据图片文件名找出对应的文字作者(class)、标签(Label)，并显示该文字图片
    Args:
        image_path (str): 文字图片路径和文件名.
        word_writer_classes_dict (dict): 文字及标签的字典
        show (Boolean): 是否显示文字图片

    Returns:
        str,str: 作者class,文字作者label

    Example:
        data\wordlib\予_行书_鲜于枢_12046.gif "_"前面的字符是书法对应的文字
        返回："鲜于枢",203
    '''
    image_writer_class = Path(str(image_path)).name.split('_')[2]
    image_writer_label =word_writer_classes_dict[image_writer_class]
    print(f'图片{image_path}对应的文字是：{image_writer_class}, 其label为: {image_writer_label}')
    
    
    with Image.open(image_path).convert('RGB') as f: #    丁_草书_王铎_131029.gif data/wordlib/zxqsig.jpg
        if show:
            plt.figure(figsize=(2,2))
            plt.imshow(f)  
            plt.title(f"图片size(H,W)为:({f.height}, {f.width})",fontsize=16,fontproperties='Simhei')
            plt.axis(False)            
    return image_writer_class,image_writer_label,f

```


```python
word_writer_classes_dict['神宗']
```




    285




```python
random_image_path = random.choice(IMAGE_PATH_LIST)
word_writer,writer_label,img=resolve_word_writer_by_image_name(random_image_path,word_writer_classes_dict,show=True)
```

    图片data\wordlib\丘_行书_王羲之_11214.gif对应的文字是：王羲之, 其label为: 266
    


    
![png](output_20_1.png)
    



```python
# 定义 transform
# 转换效果及使用方法详见：https://pytorch.org/vision/stable/auto_examples/plot_transforms.html#sphx-glr-auto-examples-plot-transforms-py
aug_transform = transforms.Compose([
    transforms.Resize((370, 370)),
    #transforms.TrivialAugmentWide(num_magnitude_bins=31,fill=255), # how intense 
    #transforms.ColorJitter(brightness=.5, hue=.3),
    transforms.RandomRotation(degrees=(-10, 10),expand=False,fill=255),
    #transforms.RandomAffine(degrees=(30, 70), translate=(0.1, 0.3), scale=(0.7, 0.9),fill=255),
    #transforms.ElasticTransform(alpha=250.0,fill=255),
    transforms.RandomPerspective(distortion_scale=0.1, p=0.2,fill=255),
    transforms.ToTensor() # use ToTensor() last to get everything between 0 & 1
])
```


```python
def plot_one_transformed_image(image_path,transform=None,save=True,save_path='data/augmented/'):
    
    '''
    show_transformed_image，根据图片文件名和Transform，显示原图片和Transformed后的图片
    Args:
        image_path (str): 文字图片路径和文件名,如'data/wordlib/书_行书_王羲之_11946.gif'
        transform (torchvision.transforms): 效果转换器

    Returns:
        None

    '''
    with Image.open(image_path).convert('RGB') as f: # 
        fig, ax = plt.subplots(figsize=(4,2))
        ax.axis(False)
        ax = fig.add_subplot(1,2,1)
        ax.imshow(f) 
        ax.set_title(f"原图\nSize: {f.size}",fontsize=16,fontproperties='Simhei')
        ax.axis("off")     
        ax = fig.add_subplot(1,2,2)
        ax.axis(False)
        if transform is not None:
            transformed_image = transform(f).permute(1,2,0) #如果只想看某一个channel的话，再接上[:,:,0]
            if transformed_image.shape[2]==1:
                transformed_image=transformed_image.squeeze(2)
            ax.imshow(transformed_image)
            ax.set_title(f"Transformed \nSize: {transformed_image.shape}",fontsize=16,fontproperties='Simhei')
            #fig.suptitle(f"{str(image_path).split('.')[0]}",fontsize=16,fontproperties='Simhei')
            
            if save:
                img=torchvision.transforms.ToPILImage()(transformed_image.permute(2,0,1))
                img_name=str(image_path).split('/')[-1]
                augmented_name=save_path+img_name.split('.')[0]+str(random.randint(100000,999999))+"_aug."+img_name.split('.')[-1]
                #print(augmented_name) #输出保存的文件名
                img.save(augmented_name)

```


```python
plot_one_transformed_image('data/wordlib/愛_行书_唐寅_28699.gif',aug_transform)
```


    
![png](output_23_0.png)
    



```python
def plot_transformed_images(image_paths, transform, n=3, seed=None,show=True,save=True,save_path='data/augmented/'):
    """Plots a series of random images from image_paths.

    Will open n image paths from image_paths, transform them
    with transform and plot them side by side.

    Args:
        image_paths (list): List of target image paths. 
        transform (PyTorch Transforms): Transforms to apply to images.
        n (int, optional): Number of images to plot. Defaults to 3.
        seed (int, optional): Random seed for the random generator. Defaults to 42.
        save: save or not the transformed image file
        save_path: where to save the transformed image file
    """
    #random.seed(42)
    random_image_paths = random.sample(image_paths, k=n)
    for image_path in random_image_paths:
        try:
            with Image.open(image_path).convert('RGB') as f:
                # 转换并显示图片
                # Note: permute() 用于进行维度交换 
                # (PyTorch default is [C, H, W] but Matplotlib is [H, W, C])
                transformed_image = transform(f).permute(1, 2, 0) 
                if transformed_image.shape[2]==1:
                    transformed_image=transformed_image.squeeze(2)
                if save:
                    img=torchvision.transforms.ToPILImage()(transformed_image.permute(2,0,1))
                    filename=image_path.name.split('.')[0]+'_'+str(random.randint(100000,999999))+'_aug.'+image_path.name.split('.')[1]   
                    #print(f'生成了新的增广变形文件{filename}')
                    img.save(f'{save_path}/{filename}')

                if show:
                    fig, ax = plt.subplots(1, 2)
                    ax[0].imshow(f) 
                    ax[0].set_title(f"Original \nSize: {f.size}")
                    ax[0].axis("off")    

                    ax[1].imshow(transformed_image)
                    ax[1].set_title(f"Transformed \nSize: {transformed_image.shape}")
                    ax[1].axis("off")
                    word_class=image_path.name.split('_')[0]
                    fig.suptitle(f"Class: {word_class}, label is :{word_classes_dict[word_class]}", fontsize=16,fontproperties='Simhei')
            
        except:
            continue
```

### 从已有的图片中增广生成新图片并保存


```python
def generate_augmented_images(k=2,size=4,image_path_list=None,aug_transform=None,save=True,show=False,save_path='data/augmented/')->None:
    """
    使用转换器随机生成增广图片并保存
    生成图片数量为：k*size
    
    Args:
        k=2:循环生成的次数
        size=4：每次取样的大小
        image_path_list=IMAGE_PATH_LIST：图片来源文件夹
        aug_transform=None：转换器
        save=True：是否保存到文件夹
        show=False：是否显示生成的图片
        save_path='data/augmented/'：文件保存路径
    """
    
    for i in range(k):
        plot_transformed_images(image_path_list, 
                            transform=aug_transform, 
                            n=size,save=True,show=False,save_path='data/augmented/')
```


```python
generate_augmented_images(10,10,image_path_list=IMAGE_PATH_LIST,aug_transform=aug_transform) #从已有的图片中增广生成100张图片
```

### 自定义继承自torch.utils.data.Dataset的数据集


```python
# 自定义继承自torch.utils.data.Dataset的数据集
from torch.utils.data import Dataset

# 1. torch.utils.data.Dataset的子类
class ImageFolderWordLibDataSet(Dataset):
    
    # 2. 用targ_dir和transform (可选)参数初始化
    def __init__(self, targ_dir: str, transform = None, ext:str='gif'):
              
        # 3. 创建类属性
        # 获取文件夹下所有的图片文件全名
        self.paths = list(pathlib.Path(targ_dir).glob(f"*.{ext}")) # note: ext为文件扩展名，可以改为 .png's或.jpeg's
        # 设置transforms
        self.transform = transform
        # 创建classes和class_to_idx属性
        self.classes, self.class_to_idx,_ = find_classes(targ_dir,ext)

    # 4. 定义加载图片的函数
    def load_image(self, index: int):
        "Opens an image via a path and returns it."
        image_path = self.paths[index]
        return Image.open(image_path).convert('RGB'),image_path
    
    # 5. 覆盖 the __len__()方法 
    def __len__(self) -> int:
        "返回样本总数"
        return len(self.paths)
    
    # 6. 覆盖 __getitem__() 方法(作为torch.utils.data.Dataset子类必须重写该方法)
    def __getitem__(self, index: int) -> Tuple[torch.Tensor, int]:
        "根据index返回一个样本的data and label (X, y)."
        img,img_path = self.load_image(index)
        class_name  = img_path.name.split('_')[0] # 命名规则为: data_dir/word_font_writer_number.gif
        class_idx = self.class_to_idx[class_name]

        # 对图片作转换
        if self.transform:
            return self.transform(img), class_idx # 返回样本data, label (X, y)
        else:
            return img, class_idx # 返回样本 data, label (X, y)
```


```python
# 自定义继承自torch.utils.data.Dataset的数据集
from torch.utils.data import Dataset

# 1. torch.utils.data.Dataset的子类
class ImageWriterWordLibDataSet(Dataset):
    
    # 2. 用targ_dir和transform (可选)参数初始化
    def __init__(self, targ_dir: str, transform = None, ext:str='gif'):
              
        # 3. 创建类属性
        # 获取文件夹下所有的图片文件全名
        self.paths = list(pathlib.Path(targ_dir).glob(f"*.{ext}")) # note: ext为文件扩展名，可以改为 .png's或.jpeg's
        # 设置transforms
        self.transform = transform
        # 创建classes和class_to_idx属性
        self.writer_classes, self.writer_class_to_idx,_ = find_writer_classes(targ_dir,ext)

    # 4. 定义加载图片的函数
    def load_image(self, index: int):
        "Opens an image via a path and returns it."
        image_path = self.paths[index]
        return Image.open(image_path).convert('RGB'),image_path
    
    # 5. 覆盖 the __len__()方法 
    def __len__(self) -> int:
        "返回样本总数"
        return len(self.paths)
    
    # 6. 覆盖 __getitem__() 方法(作为torch.utils.data.Dataset子类必须重写该方法)
    def __getitem__(self, index: int) -> Tuple[torch.Tensor, int]:
        "根据index返回一个样本的data and label (X, y)."
        img,img_path = self.load_image(index)
        writer_class_name  = img_path.name.split('_')[2] # 命名规则为: data_dir/word_font_writer_number.gif
        writer_class_idx = self.writer_class_to_idx[writer_class_name]

        # 对图片作转换
        if self.transform:
            return self.transform(img), writer_class_idx # 返回样本data, label (X, y)
        else:
            return img, writer_class_idx # 返回样本 data, label (X, y)
```


```python
# 对train data作转换
train_transforms = transforms.Compose([
    transforms.Resize((64, 64)),
    #transforms.RandomHorizontalFlip(p=0.5),
    transforms.ToTensor()
])

# 对test data只须统一shape并转换为Tensor
test_transforms = transforms.Compose([
    transforms.Resize((64, 64)),
    transforms.ToTensor()
])
```

### 实例化自定义的数据集对象，并拆分为训练集和测试集


```python
#实例化自定义的数据集对象，并拆分为训练集和测试集
data_custom = ImageFolderWordLibDataSet(targ_dir=IMAGE_PATH, 
                                        transform=train_transforms,
                                        ext='gif')
train_size=int(0.9*len(data_custom))
test_size=len(data_custom)-train_size
torch.manual_seed(42)
train_dataset,test_dataset=torch.utils.data.random_split(data_custom,[train_size,test_size])

train_dataset, test_dataset
```




    (<torch.utils.data.dataset.Subset at 0x1df83a48358>,
     <torch.utils.data.dataset.Subset at 0x1df83a48908>)




```python
len(data_custom),len(train_dataset),len(test_dataset),len(train_dataset)+len(test_dataset)
```




    (5780, 5202, 578, 5780)




```python
#实例化自定义的数据集对象，并拆分为训练集和测试集
data_writer_custom = ImageWriterWordLibDataSet(targ_dir=IMAGE_PATH, 
                                        transform=train_transforms,
                                        ext='gif')
train_writer_size=int(0.9*len(data_writer_custom))
test_writer_size=len(data_writer_custom)-train_writer_size
torch.manual_seed(42)
train_writer_dataset,test_writer_dataset=torch.utils.data.random_split(data_writer_custom,[train_writer_size,test_writer_size])

train_writer_dataset, test_writer_dataset
```




    (<torch.utils.data.dataset.Subset at 0x1df83a91e48>,
     <torch.utils.data.dataset.Subset at 0x1df83a91e80>)




```python
len(data_writer_custom),len(train_writer_dataset),len(test_writer_dataset),len(train_writer_dataset)+len(test_writer_dataset)
```




    (5780, 5202, 578, 5780)



###  创建随机显示图片的函数


```python
# 1. 输入参数为dataset、文字列表
def display_random_images(dataset: torch.utils.data.dataset.Dataset,
                          classes: List[str] = None,
                          n: int = 10,
                          display_shape: bool = True,
                          seed: int = None):
    
    # 2. 为了好的显示效果，只允许显示10张
    if n > 10:
        n = 10
        display_shape = False
        print(f"为了好的显示效果，最多只允许显示10张图片.")
    
    # 3. 设置随机种子
    if seed:
        random.seed(seed)

    # 4. 获取抽样序号
    random_samples_idx = random.sample(range(len(dataset)), k=n)

    # 5. 设置figure大小
    plt.figure(figsize=(16, 8))

    # 6. 显示每张抽取的图片
    for i, targ_sample in enumerate(random_samples_idx):
        targ_image, targ_label = dataset[targ_sample][0], dataset[targ_sample][1]

        # 7. 用permute函数调整image的tensor shape以正确显示图片:
        # tensor的维度： [color_channels, height, width] -> 画图维度[height, width,color_channels]
        targ_image_adjust = targ_image.permute(1, 2, 0) 
        if targ_image_adjust.shape[2]==1:
            targ_image_adjust=targ_image_adjust.squeeze(2)  #如果图片只有1个通道，则需要压缩维度，去掉通道信息，否则不能正常显示
        # 将n幅图画在1行
        plt.subplot(1, n, i+1)
        plt.imshow(targ_image_adjust)
        plt.axis("off")
        if classes:
            title = f"class: {classes[targ_label]}"
            if display_shape:
                title = title + f"\nshape: {targ_image_adjust.shape}"
        plt.title(title,fontproperties='simhei')
```


```python
display_random_images(train_dataset, 
                      n=18, 
                      classes=images_classes_list,
                      seed=None)
```

    为了好的显示效果，最多只允许显示10张图片.
    


    
![png](output_39_1.png)
    



```python
display_random_images(train_writer_dataset, 
                      n=18, 
                      classes=images_writer_classes_list,
                      seed=None)
```

    为了好的显示效果，最多只允许显示10张图片.
    


    
![png](output_40_1.png)
    


###  用 `DataLoader`来加载自定义的数据集


```python
os.cpu_count()
```




    4




```python
train_dataloader = DataLoader(dataset=train_dataset, # 使用自定义训练数据集
                                     batch_size=32, # 每批次加载多少样本
                                     num_workers=0, # 并行加载任务数 (越高越好，但不高于os.cpu_count(),0表示任务加载)
                                     shuffle=True) # 是否乱序加载?

test_dataloader = DataLoader(dataset=test_dataset, # 使用自定义测试数据集
                                    batch_size=32, 
                                    num_workers=0, 
                                    shuffle=False) # 不须乱序加载

train_dataloader, test_dataloader
```




    (<torch.utils.data.dataloader.DataLoader at 0x1df8779e668>,
     <torch.utils.data.dataloader.DataLoader at 0x1df8779e9e8>)




```python
train_writer_dataloader = DataLoader(dataset=train_writer_dataset, # 使用自定义训练数据集
                                     batch_size=32, # 每批次加载多少样本
                                     num_workers=0, # 并行加载任务数 (越高越好，但不高于os.cpu_count(),0表示任务加载)
                                     shuffle=True) # 是否乱序加载?

test_writer_dataloader = DataLoader(dataset=test_writer_dataset, # 使用自定义测试数据集
                                    batch_size=32, 
                                    num_workers=0, 
                                    shuffle=False) # 不须乱序加载

train_writer_dataloader, test_writer_dataloader
```




    (<torch.utils.data.dataloader.DataLoader at 0x1df877833c8>,
     <torch.utils.data.dataloader.DataLoader at 0x1df877836a0>)




```python
img, label = next(iter(train_dataloader))
# next一次加载一批
print(f"Image shape: {img.shape} -> [batch_size, color_channels, height, width]")
print(f"Label shape: {label.shape}")
```

    Image shape: torch.Size([32, 3, 64, 64]) -> [batch_size, color_channels, height, width]
    Label shape: torch.Size([32])
    


```python
img_writer, label_writer = next(iter(train_writer_dataloader))
# next一次加载一批
print(f"Image shape: {img.shape} -> [batch_size, color_channels, height, width]")
print(f"Label shape: {label.shape}")
```

    Image shape: torch.Size([32, 3, 64, 64]) -> [batch_size, color_channels, height, width]
    Label shape: torch.Size([32])
    


```python
train_transform = transforms.Compose([
    transforms.Resize((64, 64)),
    #transforms.TrivialAugmentWide(num_magnitude_bins=31,fill=255), # how intense 
    #transforms.ColorJitter(brightness=.5, hue=.3),
    #transforms.RandomRotation(degrees=(0, 180),expand=False,fill=255),
    #transforms.RandomAffine(degrees=(30, 70), translate=(0.1, 0.3), scale=(0.7, 0.9),fill=255),
    #transforms.ElasticTransform(alpha=250.0,fill=255),
    #transforms.RandomPerspective(distortion_scale=0.5, p=0.6,fill=255),
    transforms.ToTensor() # use ToTensor() last to get everything between 0 & 1
])

# 对测试集不作增广变换
test_transforms = transforms.Compose([
    transforms.Resize((64, 64)), 
    transforms.ToTensor()
])
```

###  创建TinyVGG模型类


```python
from torch import nn
class TinyVGG(nn.Module):
    """
    卷积神经网络的模型参考了下面的结构，该网站详细解释了该结构，并对模型参数作了很好的可视化: 
    https://poloclub.github.io/cnn-explainer/
    """
    def __init__(self, input_shape: int, hidden_units: int, output_shape: int) -> None:
        super().__init__()
        self.conv_block_1 = nn.Sequential(
            nn.Conv2d(in_channels=input_shape, 
                      out_channels=hidden_units, 
                      kernel_size=3, # 卷积核大小
                      stride=1, # default
                      padding=1), # options = "valid" (no padding) or "same" (output has same shape as input) or int for specific number 
            nn.ReLU(),
            nn.Conv2d(in_channels=hidden_units, 
                      out_channels=hidden_units,
                      kernel_size=3,
                      stride=1,
                      padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2,
                         stride=2) # default stride value is same as kernel_size
        )
        self.conv_block_2 = nn.Sequential(
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            
            # 下面这一步的in_features设置有一定困难，如果维度计算不准，模型将报错，建议先把self.classifier这一层去掉，看前面结构的output_shape输出，
            # 再根据这个输出确定这里的in_features
            nn.Linear(in_features=hidden_units*16*16,out_features=output_shape) 
        )
    
    def forward(self, x: torch.Tensor):
        x = self.conv_block_1(x)
        # print(x.shape)
        x = self.conv_block_2(x)
        # print(x.shape)
        x = self.classifier(x)
        # print(x.shape)
        return x
        # return self.classifier(self.conv_block_2(self.conv_block_1(x))) # 这种用法效果相同且更高效

torch.manual_seed(42)
model_0 = TinyVGG(input_shape=3, # 颜色通道 (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(images_classes_list)).to(device)
model_0
```




    TinyVGG(
      (conv_block_1): Sequential(
        (0): Conv2d(3, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (1): ReLU()
        (2): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (3): ReLU()
        (4): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
      )
      (conv_block_2): Sequential(
        (0): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (1): ReLU()
        (2): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (3): ReLU()
        (4): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
      )
      (classifier): Sequential(
        (0): Flatten(start_dim=1, end_dim=-1)
        (1): Linear(in_features=5120, out_features=483, bias=True)
      )
    )




```python
len(images_classes_list)
```




    483




```python
from torch import nn
class WriterTinyVGG(nn.Module):
    """
    卷积神经网络的模型参考了下面的结构，该网站详细解释了该结构，并对模型参数作了很好的可视化: 
    https://poloclub.github.io/cnn-explainer/
    """
    def __init__(self, input_shape: int, hidden_units: int, output_shape: int) -> None:
        super().__init__()
        self.conv_block_1 = nn.Sequential(
            nn.Conv2d(in_channels=input_shape, 
                      out_channels=hidden_units, 
                      kernel_size=3, # 卷积核大小
                      stride=1, # default
                      padding=1), # options = "valid" (no padding) or "same" (output has same shape as input) or int for specific number 
            nn.ReLU(),
            nn.Conv2d(in_channels=hidden_units, 
                      out_channels=hidden_units,
                      kernel_size=3,
                      stride=1,
                      padding=1),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=2,
                         stride=2) # default stride value is same as kernel_size
        )
        self.conv_block_2 = nn.Sequential(
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(hidden_units, hidden_units, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            
            # 下面这一步的in_features设置有一定困难，如果维度计算不准，模型将报错，建议先把self.classifier这一层去掉，看前面结构的output_shape输出，
            # 再根据这个输出确定这里的in_features
            nn.Linear(in_features=hidden_units*16*16,out_features=output_shape) 
        )
    
    def forward(self, x: torch.Tensor):
        x = self.conv_block_1(x)
        # print(x.shape)
        x = self.conv_block_2(x)
        # print(x.shape)
        x = self.classifier(x)
        # print(x.shape)
        return x
        # return self.classifier(self.conv_block_2(self.conv_block_1(x))) # 这种用法效果相同且更高效

torch.manual_seed(42)
writer_model_0 = WriterTinyVGG(input_shape=3, # 颜色通道 (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(images_writer_classes_list)).to(device)
writer_model_0
```




    WriterTinyVGG(
      (conv_block_1): Sequential(
        (0): Conv2d(3, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (1): ReLU()
        (2): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (3): ReLU()
        (4): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
      )
      (conv_block_2): Sequential(
        (0): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (1): ReLU()
        (2): Conv2d(20, 20, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1))
        (3): ReLU()
        (4): MaxPool2d(kernel_size=2, stride=2, padding=0, dilation=1, ceil_mode=False)
      )
      (classifier): Sequential(
        (0): Flatten(start_dim=1, end_dim=-1)
        (1): Linear(in_features=5120, out_features=447, bias=True)
      )
    )




```python
len(images_writer_classes_list)
```




    447




```python
# 1. 从test_dataloader中抽取一批数据用于显示
itr=iter(test_dataloader)
img_batch, label_batch= next(itr)
```


```python
# 1. 从test_dataloader中抽取一批数据用于显示
writer_itr=iter(test_writer_dataloader)
img_writer_batch, label_writer_batch= next(writer_itr)
```


```python
def plot_from_image_tensor(img_tensor):
    """
    把图片tensor显示成图片
    """
    img =img_tensor.permute(1,2,0) #如果只想看某一个channel的话，再接上[:,:,0]
    if img.shape[2]==1:
        img=img.squeeze(2)
    plt.imshow(img.cpu())  #对于在GPU上的数据集，需要调用.cpu()才能plot
    plt.axis(False)
```


```python
def result_compare(iterator,model):
    model.eval()
    with torch.inference_mode():
        image_batch, label_batch = next(iterator)
        image_batch=image_batch.to(device)
        pred_label=torch.argmax(model(image_batch),dim=1)
        #print(model_0(image_batch).shape,pred_label,label_batch)
        word_dict=dict()
        label_dict=dict()         
        fig, ax = plt.subplots(figsize=(12,6)) 
        ax.axis(False)
        for i in range(len(label_batch)):
            pred_word=images_classes_list[pred_label[i]]
            word=images_classes_list[label_batch[i]]
            ax = fig.add_subplot(4,8,i+1)
            plot_from_image_tensor(image_batch[i])
            word_dict[word] = pred_word
            label_dict[label_batch[i]]=pred_label[i]
            pred_compare=pd.DataFrame.from_dict(word_dict,orient='index')
            pred_compare.reset_index(inplace=True)
            pred_compare.columns=['实际汉字','识别结果']
    return pred_compare
```


```python
result=result_compare(itr,model_0)
result.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>21</th>
      <th>22</th>
      <th>23</th>
      <th>24</th>
      <th>25</th>
      <th>26</th>
      <th>27</th>
      <th>28</th>
      <th>29</th>
      <th>30</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>实际汉字</th>
      <td>搖</td>
      <td>万</td>
      <td>摩</td>
      <td>态</td>
      <td>伯</td>
      <td>书</td>
      <td>仲</td>
      <td>愚</td>
      <td>伤</td>
      <td>戰</td>
      <td>...</td>
      <td>也</td>
      <td>招</td>
      <td>仕</td>
      <td>悶</td>
      <td>來</td>
      <td>折</td>
      <td>恢</td>
      <td>严</td>
      <td>云</td>
      <td>九</td>
    </tr>
    <tr>
      <th>识别结果</th>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>...</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
      <td>仞</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 31 columns</p>
</div>




    
![png](output_57_1.png)
    



```python
def writer_result_compare(iterator,model):
    model.eval()
    with torch.inference_mode():
        image_writer_batch, label_writer_batch = next(iterator)
        image_writer_batch=image_writer_batch.to(device)
        pred_writer_label=torch.argmax(model(image_writer_batch),dim=1)
        #print(model_0(image_batch).shape,pred_label,label_batch)
        word_writer_dict=dict()
        label_writer_dict=dict()         
        fig, ax = plt.subplots(figsize=(12,6)) 
        ax.axis(False)
        for i in range(len(label_writer_batch)):
            pred_writer_word=images_writer_classes_list[pred_writer_label[i]]
            word_writer=images_writer_classes_list[label_writer_batch[i]]
            ax = fig.add_subplot(4,8,i+1)
            plot_from_image_tensor(image_writer_batch[i])
            word_writer_dict[word_writer] = pred_writer_word
            label_writer_dict[label_writer_batch[i]]=pred_writer_label[i]
            pred_compare=pd.DataFrame.from_dict(word_writer_dict,orient='index')
            pred_compare.reset_index(inplace=True)
            pred_compare.columns=['书写人','识别结果']
    return pred_compare
```


```python
writer_result=writer_result_compare(writer_itr,writer_model_0)
writer_result.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>14</th>
      <th>15</th>
      <th>16</th>
      <th>17</th>
      <th>18</th>
      <th>19</th>
      <th>20</th>
      <th>21</th>
      <th>22</th>
      <th>23</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>书写人</th>
      <td>苏轼</td>
      <td>鲜于枢</td>
      <td>康有为</td>
      <td>揭傒斯</td>
      <td>李东阳</td>
      <td>宋克</td>
      <td>王羲之</td>
      <td>敬世江</td>
      <td>近人</td>
      <td>董其昌</td>
      <td>...</td>
      <td>李怀琳</td>
      <td>欧阳询</td>
      <td>祝枝山</td>
      <td>何氏</td>
      <td>王知敬</td>
      <td>王铎</td>
      <td>王献之</td>
      <td>明人</td>
      <td>孙觌</td>
      <td>蔡襄</td>
    </tr>
    <tr>
      <th>识别结果</th>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>...</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>黄庭坚</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
      <td>司马丕</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 24 columns</p>
</div>




    
![png](output_59_1.png)
    



```python
from torch import nn
from torch.nn import functional as F

class Residual(nn.Module):  #@save
    def __init__(self, input_channels, num_channels,
                 use_1x1conv=False, strides=1):
        super().__init__()
        self.conv1 = nn.Conv2d(input_channels, num_channels,
                               kernel_size=3, padding=1, stride=strides)
        self.conv2 = nn.Conv2d(num_channels, num_channels,
                               kernel_size=3, padding=1)
        if use_1x1conv:
            self.conv3 = nn.Conv2d(input_channels, num_channels,
                                   kernel_size=1, stride=strides)
        else:
            self.conv3 = None
        self.bn1 = nn.BatchNorm2d(num_channels)
        self.bn2 = nn.BatchNorm2d(num_channels)

    def forward(self, X):
        Y = F.relu(self.bn1(self.conv1(X)))
        Y = self.bn2(self.conv2(Y))
        if self.conv3:
            X = self.conv3(X)
        Y += X
        return F.relu(Y)
    
```


```python
def resnet_block(input_channels, num_channels, num_residuals,
                 first_block=False):
    blk = []
    for i in range(num_residuals):
        if i == 0 and not first_block:
            blk.append(Residual(input_channels, num_channels,
                                use_1x1conv=True, strides=2))
        else:
            blk.append(Residual(num_channels, num_channels))
    return blk
```


```python
class WordRecognizeResnet(nn.Module):  #@save
    def __init__(self,classes_list):
        super().__init__()
        self.b1 = nn.Sequential(nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3),
                           nn.BatchNorm2d(64), nn.ReLU(),
                           nn.MaxPool2d(kernel_size=3, stride=2, padding=1))

        self.b2 = nn.Sequential(*resnet_block(64, 64, 2, first_block=True))
        self.b3 = nn.Sequential(*resnet_block(64, 128, 2))
        self.b4 = nn.Sequential(*resnet_block(128, 256, 2))
        self.b5 = nn.Sequential(*resnet_block(256, 512, 2))
        self.resnet=nn.Sequential(self.b1, self.b2, self.b3, self.b4, self.b5,
                    nn.AdaptiveAvgPool2d((1,1)),
                    nn.Flatten(), nn.Linear(512, len(classes_list)))
    def forward(self, X):
        return self.resnet(X)
    
```


```python
model_resnet = WordRecognizeResnet(images_classes_list).to(device)
```


```python
writer_model_resnet = WordRecognizeResnet(images_writer_classes_list).to(device)
```

### 使用`torchinfo`来获得模型信息


```python
# torchinfo这个包可以比较方便地显示模型结构和参数，如果import失败，需要安装
try: 
    import torchinfo
except:
    !pip install torchinfo
    import torchinfo
    
from torchinfo import summary
summary(model_0, input_size=img_batch.shape) # summary函数非常方便，只需要把一个batch的shape作为输入就能够得模型信息，不须加载真实数据
```




    ==========================================================================================
    Layer (type:depth-idx)                   Output Shape              Param #
    ==========================================================================================
    TinyVGG                                  [32, 483]                 --
    ├─Sequential: 1-1                        [32, 20, 32, 32]          --
    │    └─Conv2d: 2-1                       [32, 20, 64, 64]          560
    │    └─ReLU: 2-2                         [32, 20, 64, 64]          --
    │    └─Conv2d: 2-3                       [32, 20, 64, 64]          3,620
    │    └─ReLU: 2-4                         [32, 20, 64, 64]          --
    │    └─MaxPool2d: 2-5                    [32, 20, 32, 32]          --
    ├─Sequential: 1-2                        [32, 20, 16, 16]          --
    │    └─Conv2d: 2-6                       [32, 20, 32, 32]          3,620
    │    └─ReLU: 2-7                         [32, 20, 32, 32]          --
    │    └─Conv2d: 2-8                       [32, 20, 32, 32]          3,620
    │    └─ReLU: 2-9                         [32, 20, 32, 32]          --
    │    └─MaxPool2d: 2-10                   [32, 20, 16, 16]          --
    ├─Sequential: 1-3                        [32, 483]                 --
    │    └─Flatten: 2-11                     [32, 5120]                --
    │    └─Linear: 2-12                      [32, 483]                 2,473,443
    ==========================================================================================
    Total params: 2,484,863
    Trainable params: 2,484,863
    Non-trainable params: 0
    Total mult-adds (M): 864.27
    ==========================================================================================
    Input size (MB): 1.57
    Forward/backward pass size (MB): 52.55
    Params size (MB): 9.94
    Estimated Total Size (MB): 64.06
    ==========================================================================================




```python
summary(writer_model_0, input_size=img_writer_batch.shape) # summary函数非常方便，只需要把一个batch的shape作为输入就能够得模型信息，不须加载真实数据
```




    ==========================================================================================
    Layer (type:depth-idx)                   Output Shape              Param #
    ==========================================================================================
    WriterTinyVGG                            [32, 447]                 --
    ├─Sequential: 1-1                        [32, 20, 32, 32]          --
    │    └─Conv2d: 2-1                       [32, 20, 64, 64]          560
    │    └─ReLU: 2-2                         [32, 20, 64, 64]          --
    │    └─Conv2d: 2-3                       [32, 20, 64, 64]          3,620
    │    └─ReLU: 2-4                         [32, 20, 64, 64]          --
    │    └─MaxPool2d: 2-5                    [32, 20, 32, 32]          --
    ├─Sequential: 1-2                        [32, 20, 16, 16]          --
    │    └─Conv2d: 2-6                       [32, 20, 32, 32]          3,620
    │    └─ReLU: 2-7                         [32, 20, 32, 32]          --
    │    └─Conv2d: 2-8                       [32, 20, 32, 32]          3,620
    │    └─ReLU: 2-9                         [32, 20, 32, 32]          --
    │    └─MaxPool2d: 2-10                   [32, 20, 16, 16]          --
    ├─Sequential: 1-3                        [32, 447]                 --
    │    └─Flatten: 2-11                     [32, 5120]                --
    │    └─Linear: 2-12                      [32, 447]                 2,289,087
    ==========================================================================================
    Total params: 2,300,507
    Trainable params: 2,300,507
    Non-trainable params: 0
    Total mult-adds (M): 858.37
    ==========================================================================================
    Input size (MB): 1.57
    Forward/backward pass size (MB): 52.54
    Params size (MB): 9.20
    Estimated Total Size (MB): 63.32
    ==========================================================================================




```python
img_writer_batch.shape
```




    torch.Size([32, 3, 64, 64])




```python
summary(model_resnet, input_size=img_batch.shape)
```




    ==========================================================================================
    Layer (type:depth-idx)                   Output Shape              Param #
    ==========================================================================================
    WordRecognizeResnet                      [32, 483]                 --
    ├─Sequential: 1-1                        [32, 483]                 --
    │    └─Sequential: 2-1                   [32, 64, 16, 16]          --
    │    │    └─Conv2d: 3-1                  [32, 64, 32, 32]          9,472
    │    │    └─BatchNorm2d: 3-2             [32, 64, 32, 32]          128
    │    │    └─ReLU: 3-3                    [32, 64, 32, 32]          --
    │    │    └─MaxPool2d: 3-4               [32, 64, 16, 16]          --
    │    └─Sequential: 2-2                   [32, 64, 16, 16]          --
    │    │    └─Residual: 3-5                [32, 64, 16, 16]          74,112
    │    │    └─Residual: 3-6                [32, 64, 16, 16]          74,112
    │    └─Sequential: 2-3                   [32, 128, 8, 8]           --
    │    │    └─Residual: 3-7                [32, 128, 8, 8]           230,272
    │    │    └─Residual: 3-8                [32, 128, 8, 8]           295,680
    │    └─Sequential: 2-4                   [32, 256, 4, 4]           --
    │    │    └─Residual: 3-9                [32, 256, 4, 4]           919,296
    │    │    └─Residual: 3-10               [32, 256, 4, 4]           1,181,184
    │    └─Sequential: 2-5                   [32, 512, 2, 2]           --
    │    │    └─Residual: 3-11               [32, 512, 2, 2]           3,673,600
    │    │    └─Residual: 3-12               [32, 512, 2, 2]           4,721,664
    │    └─AdaptiveAvgPool2d: 2-6            [32, 512, 1, 1]           --
    │    └─Flatten: 2-7                      [32, 512]                 --
    │    └─Linear: 2-8                       [32, 483]                 247,779
    ==========================================================================================
    Total params: 11,427,299
    Trainable params: 11,427,299
    Non-trainable params: 0
    Total mult-adds (G): 4.75
    ==========================================================================================
    Input size (MB): 1.57
    Forward/backward pass size (MB): 100.26
    Params size (MB): 45.71
    Estimated Total Size (MB): 147.54
    ==========================================================================================




```python
summary(writer_model_resnet, input_size=img_writer_batch.shape)
```




    ==========================================================================================
    Layer (type:depth-idx)                   Output Shape              Param #
    ==========================================================================================
    WordRecognizeResnet                      [32, 447]                 --
    ├─Sequential: 1-1                        [32, 447]                 --
    │    └─Sequential: 2-1                   [32, 64, 16, 16]          --
    │    │    └─Conv2d: 3-1                  [32, 64, 32, 32]          9,472
    │    │    └─BatchNorm2d: 3-2             [32, 64, 32, 32]          128
    │    │    └─ReLU: 3-3                    [32, 64, 32, 32]          --
    │    │    └─MaxPool2d: 3-4               [32, 64, 16, 16]          --
    │    └─Sequential: 2-2                   [32, 64, 16, 16]          --
    │    │    └─Residual: 3-5                [32, 64, 16, 16]          74,112
    │    │    └─Residual: 3-6                [32, 64, 16, 16]          74,112
    │    └─Sequential: 2-3                   [32, 128, 8, 8]           --
    │    │    └─Residual: 3-7                [32, 128, 8, 8]           230,272
    │    │    └─Residual: 3-8                [32, 128, 8, 8]           295,680
    │    └─Sequential: 2-4                   [32, 256, 4, 4]           --
    │    │    └─Residual: 3-9                [32, 256, 4, 4]           919,296
    │    │    └─Residual: 3-10               [32, 256, 4, 4]           1,181,184
    │    └─Sequential: 2-5                   [32, 512, 2, 2]           --
    │    │    └─Residual: 3-11               [32, 512, 2, 2]           3,673,600
    │    │    └─Residual: 3-12               [32, 512, 2, 2]           4,721,664
    │    └─AdaptiveAvgPool2d: 2-6            [32, 512, 1, 1]           --
    │    └─Flatten: 2-7                      [32, 512]                 --
    │    └─Linear: 2-8                       [32, 447]                 229,311
    ==========================================================================================
    Total params: 11,408,831
    Trainable params: 11,408,831
    Non-trainable params: 0
    Total mult-adds (G): 4.75
    ==========================================================================================
    Input size (MB): 1.57
    Forward/backward pass size (MB): 100.25
    Params size (MB): 45.64
    Estimated Total Size (MB): 147.46
    ==========================================================================================



###  创建train_step和test_step函数
主要定义了三个函数:
1. `train_step()` - 输入参数为：model, `DataLoader`，loss function和optimizer
2. `test_step()` - 输入参数为：model, `DataLoader`，loss function和optimizer
3. `train()` - 定义train Loop，执行给定的epochs并返回一个结果集的dict.

* 模型训练的标准流程：
    * 0-上device
    * 1-model(x)前向算结果
    * 2-loss_fn根据结果算损失
    * 3-zero_grad梯度全归零
    * 4-backword反向传播算梯度
    * 5-step更新参数    


```python
def train_step(model: torch.nn.Module, 
               dataloader: torch.utils.data.DataLoader, 
               loss_fn: torch.nn.Module, 
               optimizer: torch.optim.Optimizer):
    # model进入训练模式
    model.train()
    
    # 设置 train loss and train accuracy values
    train_loss, train_acc = 0, 0
    
    # 对data loader的每个data批次进行训练。假如训练集有10000个数据，batch size为32的话，则有 (10000/32)=312.5经向上取整后共313个批次
    # 但这不用手动计算，将dataloader放到enumerate()函数中会自动循环获取
    # 有些代码也会使用iter(dataloader)进行循环，区别在于iter不会返回批次的序号
    
    # 0-5步为模型训练的标准流程：
    '''
    0-上device
    1-前向算结果
    2-根据结果算损失
    3-zero_grad梯度全归零
    4-backword反向传播算梯度
    5-step更新参数
    '''
    
    for batch, (X, y) in enumerate(dataloader):
        # 0. 把数据放到目标device上
        X, y = X.to(device), y.to(device)

        # 1. Forward pass
        y_pred = model(X)

        # 2. Calculate  and accumulate loss
        loss = loss_fn(y_pred, y)
        train_loss += loss.item()   #loss_fn返回的是tensor，调用.item()转换为numpy的值

        # 3. Optimizer zero grad
        optimizer.zero_grad()

        # 4. Loss backward
        loss.backward()

        # 5. Optimizer step
        optimizer.step()

        # 6. Calculate and accumulate accuracy metric across all batches
        y_pred_class = torch.argmax(torch.softmax(y_pred, dim=1), dim=1)
        train_acc += (y_pred_class == y).sum().item()/len(y_pred)

    # 计算每批次loss和accuracy的平均数
    train_loss = train_loss / len(dataloader)
    train_acc = train_acc / len(dataloader)
    return train_loss, train_acc
```


```python
def test_step(model: torch.nn.Module, 
              dataloader: torch.utils.data.DataLoader, 
              loss_fn: torch.nn.Module):
    # 开启test模式，有些dropout的层将跳过
    model.eval() 
    
    # 设置 test loss 和 test accuracy为0
    test_loss, test_acc = 0, 0
    
    # 不会进行梯度计算，以加快运行速度
    with torch.inference_mode():
        # Loop through DataLoader batches
        for batch, (X, y) in enumerate(dataloader):
            # Send data to target device
            X, y = X.to(device), y.to(device)
    
            # 1. Forward pass
            test_pred_logits = model(X)

            # 2. Calculate and accumulate loss
            loss = loss_fn(test_pred_logits, y)
            test_loss += loss.item()
            
            # Calculate and accumulate accuracy
            test_pred_labels = test_pred_logits.argmax(dim=1)
            test_acc += ((test_pred_labels == y).sum().item()/len(test_pred_labels))
            
    # 计算每个test batch平均损失和准确度
    test_loss = test_loss / len(dataloader)
    test_acc = test_acc / len(dataloader)
    return test_loss, test_acc
```

### 创建训练Loop:将train_step()和test_step()放在train()函数中 

1. 传入参数：model, 封装了训练集和测试集的`DataLoader`，优化器optimizer, 损失函数loss_fn，训练和测试的循环次数epochs
2. 创建空的`train_loss`, `train_acc`, `test_loss` , `test_acc` 字典
3. 对epoches中的每个epoch循环运行train()和test().
4. 输出每个epoch的过程信息.
5. 更新每个epoch的metrics字典.
6. 返回结果



```python
# 1. 定义train函数和传入参数
def train(model: torch.nn.Module, 
          train_dataloader: torch.utils.data.DataLoader, 
          test_dataloader: torch.utils.data.DataLoader, 
          optimizer: torch.optim.Optimizer,
          loss_fn: torch.nn.Module = nn.CrossEntropyLoss(),
          epochs: int = 5):
    
    # 2. 创建空字典用于存储结果
    results = {"train_loss": [],
        "train_acc": [],
        "test_loss": [],
        "test_acc": []
    }
    
    # 3. Training循环
    for epoch in tqdm(range(epochs)):
        train_loss, train_acc = train_step(model=model,
                                           dataloader=train_dataloader,
                                           loss_fn=loss_fn,
                                           optimizer=optimizer)
        test_loss, test_acc = test_step(model=model,
                                        dataloader=test_dataloader,
                                        loss_fn=loss_fn)
        
        # 4. 输出结果
        print(
            f"Epoch: {epoch+1} | "
            f"train_loss: {train_loss:.4f} | "
            f"train_acc: {train_acc:.4f} | "
            f"test_loss: {test_loss:.4f} | "
            f"test_acc: {test_acc:.4f}"
        )

        # 5. 更新结果字典
        results["train_loss"].append(train_loss)
        results["train_acc"].append(train_acc)
        results["test_loss"].append(test_loss)
        results["test_acc"].append(test_acc)

    # 6. 训练结束返回结果
    return results
```
# 设置随机种子
torch.manual_seed(42) 
torch.cuda.manual_seed(42)

# 设置epochs次数
NUM_EPOCHS = 10

# 实例化模型
model_0 = TinyVGG(input_shape=3, # number of color channels (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(data_custom.classes)).to(device)

# 设置损失函数和优化器
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(params=model_0.parameters(), lr=0.001)

# 用timer开始计时

start_time = timer()

# 开始训练模型model_0 
model_0_results = train(model=model_0, 
                        train_dataloader=train_dataloader,
                        test_dataloader=test_dataloader,
                        optimizer=optimizer,
                        loss_fn=loss_fn, 
                        epochs=NUM_EPOCHS)

# 训练结束，输出训练时长
end_time = timer()
print(f"训练时长: {end_time-start_time:.3f} seconds")

```python
# 设置随机种子
torch.manual_seed(42) 
torch.cuda.manual_seed(42)

# 设置epochs次数
NUM_EPOCHS = 20

# 实例化模型
model_0_resnet = WordRecognizeResnet(images_classes_list).to(device)

# 设置损失函数和优化器
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(params=model_0_resnet.parameters(), lr=0.001)

# 用timer开始计时

start_time = timer()

# 开始训练模型model_0 
model_0_resnet_results = train(model=model_0_resnet, 
                        train_dataloader=train_dataloader,
                        test_dataloader=test_dataloader,
                        optimizer=optimizer,
                        loss_fn=loss_fn, 
                        epochs=NUM_EPOCHS)

# 训练结束，输出训练时长
end_time = timer()
print(f"训练时长: {end_time-start_time:.3f} seconds")
```

      5%|████                                                                              | 1/20 [03:00<57:08, 180.46s/it]

    Epoch: 1 | train_loss: 5.9907 | train_acc: 0.0153 | test_loss: 5.8393 | test_acc: 0.0230
    

     10%|████████▏                                                                         | 2/20 [05:57<53:34, 178.59s/it]

    Epoch: 2 | train_loss: 5.1389 | train_acc: 0.0439 | test_loss: 4.6881 | test_acc: 0.0576
    

     15%|████████████▎                                                                     | 3/20 [08:58<50:53, 179.59s/it]

    Epoch: 3 | train_loss: 4.2107 | train_acc: 0.1131 | test_loss: 6.1919 | test_acc: 0.0345
    

     20%|████████████████▍                                                                 | 4/20 [11:59<47:59, 179.95s/it]

    Epoch: 4 | train_loss: 3.4165 | train_acc: 0.2081 | test_loss: 3.8802 | test_acc: 0.1546
    

     25%|████████████████████▌                                                             | 5/20 [15:07<45:47, 183.18s/it]

    Epoch: 5 | train_loss: 2.7438 | train_acc: 0.3177 | test_loss: 3.7964 | test_acc: 0.1826
    

     30%|████████████████████████▌                                                         | 6/20 [18:33<44:31, 190.79s/it]

    Epoch: 6 | train_loss: 2.1419 | train_acc: 0.4267 | test_loss: 2.5704 | test_acc: 0.3832
    

     35%|████████████████████████████▋                                                     | 7/20 [22:07<43:00, 198.48s/it]

    Epoch: 7 | train_loss: 1.6650 | train_acc: 0.5357 | test_loss: 2.7858 | test_acc: 0.3322
    

     40%|████████████████████████████████▊                                                 | 8/20 [25:05<38:22, 191.88s/it]

    Epoch: 8 | train_loss: 1.2764 | train_acc: 0.6325 | test_loss: 2.3290 | test_acc: 0.4819
    

     45%|████████████████████████████████████▉                                             | 9/20 [28:32<36:01, 196.47s/it]

    Epoch: 9 | train_loss: 1.0144 | train_acc: 0.6946 | test_loss: 2.0297 | test_acc: 0.5181
    

     50%|████████████████████████████████████████▌                                        | 10/20 [31:25<31:32, 189.23s/it]

    Epoch: 10 | train_loss: 0.7543 | train_acc: 0.7647 | test_loss: 2.0662 | test_acc: 0.5296
    

     55%|████████████████████████████████████████████▌                                    | 11/20 [34:20<27:43, 184.86s/it]

    Epoch: 11 | train_loss: 0.5875 | train_acc: 0.8071 | test_loss: 1.7567 | test_acc: 0.5855
    

     60%|████████████████████████████████████████████████▌                                | 12/20 [37:13<24:11, 181.43s/it]

    Epoch: 12 | train_loss: 0.4709 | train_acc: 0.8400 | test_loss: 1.7588 | test_acc: 0.6069
    

     65%|████████████████████████████████████████████████████▋                            | 13/20 [40:07<20:54, 179.26s/it]

    Epoch: 13 | train_loss: 0.3927 | train_acc: 0.8669 | test_loss: 1.6553 | test_acc: 0.6497
    

     70%|████████████████████████████████████████████████████████▋                        | 14/20 [43:03<17:48, 178.04s/it]

    Epoch: 14 | train_loss: 0.3323 | train_acc: 0.8831 | test_loss: 1.6447 | test_acc: 0.6513
    

     75%|████████████████████████████████████████████████████████████▊                    | 15/20 [45:57<14:44, 176.87s/it]

    Epoch: 15 | train_loss: 0.3049 | train_acc: 0.8919 | test_loss: 1.8987 | test_acc: 0.5740
    

     80%|████████████████████████████████████████████████████████████████▊                | 16/20 [48:51<11:43, 175.92s/it]

    Epoch: 16 | train_loss: 0.2791 | train_acc: 0.8996 | test_loss: 1.7953 | test_acc: 0.6299
    

     85%|████████████████████████████████████████████████████████████████████▊            | 17/20 [51:44<08:45, 175.25s/it]

    Epoch: 17 | train_loss: 0.2641 | train_acc: 0.8987 | test_loss: 1.5576 | test_acc: 0.6743
    

     90%|████████████████████████████████████████████████████████████████████████▉        | 18/20 [54:39<05:50, 175.07s/it]

    Epoch: 18 | train_loss: 0.2431 | train_acc: 0.9003 | test_loss: 1.8189 | test_acc: 0.5872
    

     95%|████████████████████████████████████████████████████████████████████████████▉    | 19/20 [57:35<02:55, 175.33s/it]

    Epoch: 19 | train_loss: 0.2696 | train_acc: 0.8912 | test_loss: 1.7668 | test_acc: 0.6382
    

    100%|███████████████████████████████████████████████████████████████████████████████| 20/20 [1:00:29<00:00, 181.47s/it]

    Epoch: 20 | train_loss: 0.2497 | train_acc: 0.8994 | test_loss: 1.7332 | test_acc: 0.6036
    训练时长: 3629.356 seconds
    

    
    
# 设置随机种子
torch.manual_seed(42) 
torch.cuda.manual_seed(42)

# 设置epochs次数
NUM_EPOCHS =20

# 实例化模型
writer_model_0 = WriterTinyVGG(input_shape=3, # number of color channels (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(data_writer_custom.writer_classes)).to(device)

# 设置损失函数和优化器
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(params=writer_model_0.parameters(), lr=0.001)

# 用timer开始计时

start_time = timer()

# 开始训练模型model_0 
writer_model_0_results = train(model=writer_model_0, 
                        train_dataloader=train_writer_dataloader,
                        test_dataloader=test_writer_dataloader,
                        optimizer=optimizer,
                        loss_fn=loss_fn, 
                        epochs=NUM_EPOCHS)

# 训练结束，输出训练时长
end_time = timer()
print(f"训练时长: {end_time-start_time:.3f} seconds")
### 查看预测结果


```python
# 设置随机种子
torch.manual_seed(42) 
torch.cuda.manual_seed(42)

# 设置epochs次数
NUM_EPOCHS =20

# 实例化模型
writer_model_0_resnet =WordRecognizeResnet(images_writer_classes_list).to(device)

# 设置损失函数和优化器
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(params=writer_model_0_resnet.parameters(), lr=0.001)

# 用timer开始计时

start_time = timer()

# 开始训练模型model_0 
writer_model_0_results_resnet = train(model=writer_model_0_resnet, 
                        train_dataloader=train_writer_dataloader,
                        test_dataloader=test_writer_dataloader,
                        optimizer=optimizer,
                        loss_fn=loss_fn, 
                        epochs=NUM_EPOCHS)

# 训练结束，输出训练时长
end_time = timer()
print(f"训练时长: {end_time-start_time:.3f} seconds")
```

      5%|████                                                                              | 1/20 [02:45<52:19, 165.25s/it]

    Epoch: 1 | train_loss: 4.4716 | train_acc: 0.1083 | test_loss: 4.4010 | test_acc: 0.1250
    

     10%|████████▏                                                                         | 2/20 [05:30<49:30, 165.05s/it]

    Epoch: 2 | train_loss: 4.1958 | train_acc: 0.1316 | test_loss: 4.2867 | test_acc: 0.1118
    

     15%|████████████▎                                                                     | 3/20 [08:15<46:46, 165.07s/it]

    Epoch: 3 | train_loss: 4.0732 | train_acc: 0.1568 | test_loss: 4.1659 | test_acc: 0.1332
    

     20%|████████████████▍                                                                 | 4/20 [11:01<44:05, 165.37s/it]

    Epoch: 4 | train_loss: 3.9671 | train_acc: 0.1750 | test_loss: 4.3156 | test_acc: 0.1743
    

     25%|████████████████████▌                                                             | 5/20 [13:49<41:35, 166.35s/it]

    Epoch: 5 | train_loss: 3.8506 | train_acc: 0.1983 | test_loss: 4.2949 | test_acc: 0.1743
    

     30%|████████████████████████▌                                                         | 6/20 [16:37<38:58, 167.06s/it]

    Epoch: 6 | train_loss: 3.7289 | train_acc: 0.2173 | test_loss: 4.2460 | test_acc: 0.1678
    

     35%|████████████████████████████▋                                                     | 7/20 [19:28<36:28, 168.33s/it]

    Epoch: 7 | train_loss: 3.5943 | train_acc: 0.2317 | test_loss: 4.2466 | test_acc: 0.1694
    

     40%|████████████████████████████████▊                                                 | 8/20 [22:16<33:37, 168.14s/it]

    Epoch: 8 | train_loss: 3.4161 | train_acc: 0.2568 | test_loss: 4.3625 | test_acc: 0.1743
    

     45%|████████████████████████████████████▉                                             | 9/20 [25:03<30:47, 167.95s/it]

    Epoch: 9 | train_loss: 3.2191 | train_acc: 0.2860 | test_loss: 4.1251 | test_acc: 0.2237
    

     50%|████████████████████████████████████████▌                                        | 10/20 [27:51<27:57, 167.80s/it]

    Epoch: 10 | train_loss: 2.9600 | train_acc: 0.3229 | test_loss: 4.4370 | test_acc: 0.2188
    

     55%|████████████████████████████████████████████▌                                    | 11/20 [30:38<25:09, 167.72s/it]

    Epoch: 11 | train_loss: 2.7064 | train_acc: 0.3641 | test_loss: 4.5057 | test_acc: 0.2253
    

     60%|████████████████████████████████████████████████▌                                | 12/20 [33:27<22:24, 168.02s/it]

    Epoch: 12 | train_loss: 2.3493 | train_acc: 0.4364 | test_loss: 4.9983 | test_acc: 0.2204
    

     65%|████████████████████████████████████████████████████▋                            | 13/20 [36:15<19:35, 167.91s/it]

    Epoch: 13 | train_loss: 1.9737 | train_acc: 0.5037 | test_loss: 4.8503 | test_acc: 0.2582
    

     70%|████████████████████████████████████████████████████████▋                        | 14/20 [39:03<16:48, 168.05s/it]

    Epoch: 14 | train_loss: 1.5700 | train_acc: 0.5881 | test_loss: 5.0135 | test_acc: 0.2697
    

     75%|████████████████████████████████████████████████████████████▊                    | 15/20 [41:52<14:01, 168.24s/it]

    Epoch: 15 | train_loss: 1.1699 | train_acc: 0.6827 | test_loss: 5.3904 | test_acc: 0.2812
    

     80%|████████████████████████████████████████████████████████████████▊                | 16/20 [44:40<11:13, 168.32s/it]

    Epoch: 16 | train_loss: 0.8281 | train_acc: 0.7738 | test_loss: 5.6675 | test_acc: 0.2845
    

     85%|████████████████████████████████████████████████████████████████████▊            | 17/20 [47:29<08:25, 168.49s/it]

    Epoch: 17 | train_loss: 0.5324 | train_acc: 0.8601 | test_loss: 6.3112 | test_acc: 0.2812
    

     90%|████████████████████████████████████████████████████████████████████████▉        | 18/20 [50:18<05:37, 168.68s/it]

    Epoch: 18 | train_loss: 0.3252 | train_acc: 0.9184 | test_loss: 6.2109 | test_acc: 0.2845
    

     95%|████████████████████████████████████████████████████████████████████████████▉    | 19/20 [53:07<02:48, 168.68s/it]

    Epoch: 19 | train_loss: 0.1944 | train_acc: 0.9562 | test_loss: 6.6074 | test_acc: 0.2615
    

    100%|█████████████████████████████████████████████████████████████████████████████████| 20/20 [55:56<00:00, 167.81s/it]

    Epoch: 20 | train_loss: 0.1309 | train_acc: 0.9737 | test_loss: 6.6981 | test_acc: 0.3207
    训练时长: 3356.118 seconds
    

    
    


```python
model_0_df = pd.DataFrame(model_0_resnet_results) 
model_0_df.to_csv('data/model_0_resnet_results.csv')
model_0_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>train_loss</th>
      <th>train_acc</th>
      <th>test_loss</th>
      <th>test_acc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.990737</td>
      <td>0.015295</td>
      <td>5.839283</td>
      <td>0.023026</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.138887</td>
      <td>0.043903</td>
      <td>4.688107</td>
      <td>0.057566</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.210695</td>
      <td>0.113071</td>
      <td>6.191893</td>
      <td>0.034539</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3.416504</td>
      <td>0.208142</td>
      <td>3.880198</td>
      <td>0.154605</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2.743790</td>
      <td>0.317698</td>
      <td>3.796365</td>
      <td>0.182566</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2.141879</td>
      <td>0.426657</td>
      <td>2.570436</td>
      <td>0.383224</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.665044</td>
      <td>0.535702</td>
      <td>2.785766</td>
      <td>0.332237</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1.276399</td>
      <td>0.632520</td>
      <td>2.328986</td>
      <td>0.481908</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.014440</td>
      <td>0.694572</td>
      <td>2.029737</td>
      <td>0.518092</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.754291</td>
      <td>0.764698</td>
      <td>2.066205</td>
      <td>0.529605</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.587527</td>
      <td>0.807111</td>
      <td>1.756694</td>
      <td>0.585526</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.470872</td>
      <td>0.839958</td>
      <td>1.758765</td>
      <td>0.606908</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.392686</td>
      <td>0.866927</td>
      <td>1.655318</td>
      <td>0.649671</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.332300</td>
      <td>0.883073</td>
      <td>1.644686</td>
      <td>0.651316</td>
    </tr>
    <tr>
      <th>14</th>
      <td>0.304873</td>
      <td>0.891935</td>
      <td>1.898652</td>
      <td>0.574013</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.279109</td>
      <td>0.899625</td>
      <td>1.795270</td>
      <td>0.629934</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0.264147</td>
      <td>0.898709</td>
      <td>1.557555</td>
      <td>0.674342</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0.243082</td>
      <td>0.900328</td>
      <td>1.818946</td>
      <td>0.587171</td>
    </tr>
    <tr>
      <th>18</th>
      <td>0.269581</td>
      <td>0.891232</td>
      <td>1.766781</td>
      <td>0.638158</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0.249732</td>
      <td>0.899433</td>
      <td>1.733202</td>
      <td>0.603618</td>
    </tr>
  </tbody>
</table>
</div>


writer_model_0_df = pd.DataFrame(writer_model_0_results_resnet) 
writer_model_0_df.to_csv('data/writer_model_0_results_resnet.csv')
writer_model_0_df
### 绘制训练过程曲线


```python
def plot_loss_curves(results: Dict[str, List[float]]):
    """绘制训练过程曲线.

    Args:
        results (dict): 训练过程记录dict,包括：
            {"train_loss": [...],
             "train_acc": [...],
             "test_loss": [...],
             "test_acc": [...]}
    """
    
    # 获取Train和test过程的loss值
    loss = results['train_loss']
    test_loss = results['test_loss']

    # 获取train和test过程的准确度acc值
    accuracy = results['train_acc']
    test_accuracy = results['test_acc']

    # 获取训练经历的epoches
    epochs = range(len(results['train_loss']))

    plt.figure(figsize=(12, 4))

    # Plot loss
    plt.subplot(1, 2, 1)
    plt.plot(epochs, loss, label='train_loss')
    plt.plot(epochs, test_loss, label='test_loss')
    plt.title('Loss-损失', fontsize=16,fontproperties='Simhei')
    plt.xlabel('Epochs-训练轮次', fontsize=16,fontproperties='Simhei')
    plt.legend()

    # Plot accuracy
    plt.subplot(1, 2, 2)
    plt.plot(epochs, accuracy, label='train_accuracy-')
    plt.plot(epochs, test_accuracy, label='test_accuracy')
    plt.title('Accuracy-准确度', fontsize=16,fontproperties='Simhei')
    plt.xlabel('Epochs-训练轮次', fontsize=16,fontproperties='Simhei')
    plt.legend();
```


```python
result=result_compare(itr,model_0_resnet)
result.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>20</th>
      <th>21</th>
      <th>22</th>
      <th>23</th>
      <th>24</th>
      <th>25</th>
      <th>26</th>
      <th>27</th>
      <th>28</th>
      <th>29</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>实际汉字</th>
      <td>佥</td>
      <td>侔</td>
      <td>播</td>
      <td>乃</td>
      <td>撫</td>
      <td>我</td>
      <td>慟</td>
      <td>招</td>
      <td>感</td>
      <td>推</td>
      <td>...</td>
      <td>慈</td>
      <td>不</td>
      <td>丛</td>
      <td>慢</td>
      <td>急</td>
      <td>戮</td>
      <td>把</td>
      <td>俘</td>
      <td>悚</td>
      <td>为</td>
    </tr>
    <tr>
      <th>识别结果</th>
      <td>愈</td>
      <td>侔</td>
      <td>播</td>
      <td>乃</td>
      <td>抚</td>
      <td>我</td>
      <td>恸</td>
      <td>招</td>
      <td>成</td>
      <td>推</td>
      <td>...</td>
      <td>慈</td>
      <td>不</td>
      <td>慕</td>
      <td>愤</td>
      <td>患</td>
      <td>戮</td>
      <td>把</td>
      <td>俘</td>
      <td>悚</td>
      <td>为</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 30 columns</p>
</div>




    
![png](output_85_1.png)
    



```python
plot_loss_curves(model_0_resnet_results) 
```


    
![png](output_86_0.png)
    

writer_result=writer_result_compare(writer_itr,writer_model_0_resnet)
writer_result.Tplot_loss_curves(writer_model_0_results_resnet) 
###  保存和加载训练好的模型
* `torch.save` - 保存PyTorch模型或模型的参数`state_dict()`. 
* `torch.load` - 加载已保存的PyTorch对象.
* `torch.nn.Module.load_state_dict()` - 加载通过保存的`state_dict()`模型参数到新的model实例中.


```python
from pathlib import Path

# 创建用于保存模型的文件夹(如果已存在则不操作), see: https://docs.python.org/3/library/pathlib.html#pathlib.Path.mkdir
MODEL_PATH = Path("data/models")
MODEL_PATH.mkdir(parents=True, #  
                 exist_ok=True # 如果路径存在也不报错
)

MODEL_NAME = "CalligraphyRegTinyVGG.pth"
MODEL_SAVE_PATH = MODEL_PATH / MODEL_NAME
MODEL_WRITER_NAME = "CalligraphyWriterRegTinyVGG.pth"
MODEL_WRITER_SAVE_PATH = MODEL_PATH / MODEL_WRITER_NAME

MODEL_NAME_RESNET = "CalligraphyRegTinyVGG_resnet.pth"
MODEL_SAVE_PATH_RESNET = MODEL_PATH / MODEL_NAME_RESNET
MODEL_WRITER_NAME_RESNET = "CalligraphyWriterRegTinyVGG_resnet.pth"
MODEL_WRITER_SAVE_PATH_RESNET = MODEL_PATH / MODEL_WRITER_NAME_RESNET
 
```


```python
# 保存模型的state dict
print(f"Saving word regcognizer model to: {MODEL_SAVE_PATH}, word writer recognizer model to :{MODEL_WRITER_SAVE_PATH}")
'''
torch.save(obj=model_0.state_dict(), # 只保存state_dict()中可学习的参数
           f=MODEL_SAVE_PATH)
torch.save(obj=writer_model_0.state_dict(), # 只保存state_dict()中可学习的参数
           f=MODEL_WRITER_SAVE_PATH)

'''
torch.save(obj=model_0_resnet.state_dict(), # 只保存state_dict()中可学习的参数
           f=MODEL_SAVE_PATH_RESNET)

torch.save(obj=writer_model_0_resnet.state_dict(), # 只保存state_dict()中可学习的参数
           f=MODEL_WRITER_SAVE_PATH_RESNET)

```

    Saving word regcognizer model to: data\models\CalligraphyRegTinyVGG.pth, word writer recognizer model to :data\models\CalligraphyWriterRegTinyVGG.pth
    


```python
# 创建一个和保存的参数具有相同结构的模型实例，否则会报错
loaded_model_0 = TinyVGG(input_shape=3, # number of color channels (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(data_custom.classes))
# 加载state_dict()
loaded_model_0.load_state_dict(torch.load(f=MODEL_SAVE_PATH,map_location=torch.device(device)))

# 将模型发送到相应的device
loaded_model_0 = loaded_model_0.to(device)

```


```python
# 创建一个和保存的参数具有相同结构的模型实例，否则会报错
loaded_model_0_resnet = WordRecognizeResnet(images_classes_list)
# 加载state_dict()
loaded_model_0_resnet.load_state_dict(torch.load(f=MODEL_SAVE_PATH_RESNET,map_location=torch.device(device)))

# 将模型发送到相应的device
loaded_model_0_resnet = loaded_model_0_resnet.to(device)

```


```python
# 创建一个和保存的参数具有相同结构的模型实例，否则会报错
loaded_writer_model_0 = WriterTinyVGG(input_shape=3, # number of color channels (3 for RGB) 
                  hidden_units=20, 
                  output_shape=len(data_writer_custom.writer_classes))
# 加载state_dict()
loaded_writer_model_0.load_state_dict(torch.load(f=MODEL_WRITER_SAVE_PATH,map_location=torch.device(device)))

# 将模型发送到相应的device
loaded_writer_model_0 = loaded_writer_model_0.to(device)
```


```python
MODEL_SAVE_PATH_RESNET
```




    WindowsPath('data/models/CalligraphyRegTinyVGG_resnet.pth')




```python
# 创建一个和保存的参数具有相同结构的模型实例，否则会报错
loaded_writer_model_0_resnet = WordRecognizeResnet(images_writer_classes_list)
# 加载state_dict()
loaded_writer_model_0_resnet.load_state_dict(torch.load(f=MODEL_WRITER_SAVE_PATH_RESNET,map_location=torch.device(device)))

# 将模型发送到相应的device
loaded_writer_model_0_resnet = loaded_writer_model_0_resnet.to(device)

```

### 使用预训练模型作预测


```python
# 1. 从test_dataloader中抽取一批数据用于显示
itr=iter(test_dataloader)
img_batch, label_batch= next(itr)
```


```python
result_resnet=result_compare(itr,loaded_model_0_resnet)
result_resnet.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>21</th>
      <th>22</th>
      <th>23</th>
      <th>24</th>
      <th>25</th>
      <th>26</th>
      <th>27</th>
      <th>28</th>
      <th>29</th>
      <th>30</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>实际汉字</th>
      <td>搖</td>
      <td>万</td>
      <td>摩</td>
      <td>态</td>
      <td>伯</td>
      <td>书</td>
      <td>仲</td>
      <td>愚</td>
      <td>伤</td>
      <td>戰</td>
      <td>...</td>
      <td>也</td>
      <td>招</td>
      <td>仕</td>
      <td>悶</td>
      <td>來</td>
      <td>折</td>
      <td>恢</td>
      <td>严</td>
      <td>云</td>
      <td>九</td>
    </tr>
    <tr>
      <th>识别结果</th>
      <td>摇</td>
      <td>万</td>
      <td>扉</td>
      <td>態</td>
      <td>伯</td>
      <td>买</td>
      <td>仲</td>
      <td>愚</td>
      <td>佚</td>
      <td>战</td>
      <td>...</td>
      <td>也</td>
      <td>拓</td>
      <td>仕</td>
      <td>悶</td>
      <td>恭</td>
      <td>折</td>
      <td>怪</td>
      <td>严</td>
      <td>云</td>
      <td>九</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 31 columns</p>
</div>




    
![png](output_99_1.png)
    



```python
writer_result_resnet=writer_result_compare(writer_itr,loaded_writer_model_0_resnet)
writer_result_resnet.T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
      <th>4</th>
      <th>5</th>
      <th>6</th>
      <th>7</th>
      <th>8</th>
      <th>9</th>
      <th>...</th>
      <th>12</th>
      <th>13</th>
      <th>14</th>
      <th>15</th>
      <th>16</th>
      <th>17</th>
      <th>18</th>
      <th>19</th>
      <th>20</th>
      <th>21</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>书写人</th>
      <td>董其昌</td>
      <td>孙虔礼</td>
      <td>陆柬之</td>
      <td>沈复</td>
      <td>颜真卿</td>
      <td>苏轼</td>
      <td>王铎</td>
      <td>王图炳</td>
      <td>谢安</td>
      <td>欧阳询</td>
      <td>...</td>
      <td>饶介</td>
      <td>李建中</td>
      <td>刘穆之</td>
      <td>鲜于枢</td>
      <td>黄庭坚</td>
      <td>近人</td>
      <td>敬世江</td>
      <td>陈邦彦</td>
      <td>沈粲</td>
      <td>陈逵</td>
    </tr>
    <tr>
      <th>识别结果</th>
      <td>米芾</td>
      <td>孙过庭</td>
      <td>欧阳询</td>
      <td>欧阳询</td>
      <td>颜真卿</td>
      <td>苏轼</td>
      <td>王铎</td>
      <td>敬世江</td>
      <td>谢安</td>
      <td>陈淳</td>
      <td>...</td>
      <td>米芾</td>
      <td>李建中</td>
      <td>刘穆之</td>
      <td>近人</td>
      <td>赵慎</td>
      <td>近人</td>
      <td>敬世江</td>
      <td>张照</td>
      <td>王羲之</td>
      <td>董其昌</td>
    </tr>
  </tbody>
</table>
<p>2 rows × 22 columns</p>
</div>




    
![png](output_100_1.png)
    



```python
def get_image_by_file_name(image_path,show=True)->(str,str,Image):
    
    '''
    定义函数 get_image_by_file_name，根据图片文件名返回图片内容，并显示该图片
    Args:
        image_path (str): 文字图片路径和文件名.
        show (Boolean): 是否显示文字图片

    Returns:
        img:图片内容

    Example:
        data\wordlib\予_行书_鲜于枢_12046.gif "_"前面的字符是书法对应的文字
        
    '''  
    print(image_path)
    img=Image.open(image_path).convert('RGB')  #    丁_草书_王铎_131029.gif data/wordlib/zxqsig.jpg
    if show:
            plt.figure(figsize=(2, 2)) 
            plt.imshow(img)  
            plt.title(f"图片size(H,W)为:({img.height}, {img.width})",fontsize=16,fontproperties='Simhei')
            plt.axis(False)    
    return img
```


```python
def predict_by_image_name(image_path,model):
    model.eval()
    with torch.inference_mode():
        query_image=get_image_by_file_name(image_path,show=True)        
        img=test_transforms(query_image).unsqueeze(0).to(device)
        pred_label=torch.argmax(model(img),dim=1)        
        print(f'\n图片文字预测为:\"{images_classes_list[pred_label]}\"，其Label为{pred_label.item()}')
    return images_classes_list[pred_label], pred_label.item()
```


```python
def predict_writer_by_image_name(image_path,model):
    model.eval()
    with torch.inference_mode():
        query_image=get_image_by_file_name(image_path,show=True)        
        img=test_transforms(query_image).unsqueeze(0).to(device)
        pred_label=torch.argmax(model(img),dim=1)        
        print(f'\n图片文字预测为:\"{images_writer_classes_list[pred_label]}\"，其Label为{pred_label.item()}')
    return images_writer_classes_list[pred_label], pred_label.item()
```


```python
predict_by_image_name(r'data\wordlib\擬_行书_苏轼_31314.gif',loaded_model_0_resnet)
```

    data\wordlib\擬_行书_苏轼_31314.gif
    
    图片文字预测为:"擬"，其Label为477
    




    ('擬', 477)




    
![png](output_104_2.png)
    


###  更多参考

* PyTorch `Dataset` and `DataLoader`[datasets and dataloaders tutorial notebook](https://pytorch.org/tutorials/beginner/basics/data_tutorial.html).
* PyTorch `torchvision.transforms`[ documentation](https://pytorch.org/vision/stable/transforms.html).
* Demos of `transforms` in action in the [illustrations of transforms tutorial](https://pytorch.org/vision/stable/auto_examples/plot_transforms.html#illustration-of-transforms). 
* PyTorch [`torchvision.datasets` documentation](https://pytorch.org/vision/stable/datasets.html).


```python

```
